import ComponentA from "./ComponentA";
import ComponentC from "./ComponentC";


function ComponentB(){
    return(<div><ComponentC/></div>)
}

export default ComponentB;